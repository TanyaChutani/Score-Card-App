package com.example.andriod.pj2; /**
 * IMPORTANT: Add your package below. Package name can be found in the project's AndroidManifest.xml file.
 * This is the package name our example uses:
 * <p>

 * package com.example.android.justjava;
 */


import android.icu.text.NumberFormat;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;


/**likhne do teh
 * This app displays an order form to order coffee.
 */
public class MainActivity extends AppCompatActivity {
    int n=0,n1=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    /**
     * This method is called when the order button is clicked.
     */
    public void incrementBy(View view) {
        n=n+3;
        displayForA(n);
    }
    public void inc(View view) {
        n++;
        displayForA(n);
    }
    public void incBy(View View)
    {
        n=n+2;
        displayForA(n);
    }
    public void incremBy(View view) {
        n1=n1+3;
        displayForB(n1);
    }
    public void incr(View view) {
        n1++;
        displayForB(n1);
    }
    public void incrBy(View View)
    {
        n1=n1+2;
        displayForB(n1);
    }

    /**
     * This method displays the given quantity value on the screen.
     */
    private void displayForA(int number) {
        TextView quantityTextView = (TextView) findViewById(R.id.team1);
        quantityTextView.setText("" + number);
    }
    private void displayForB(int number) {
        TextView quantityTextView = (TextView) findViewById(R.id.team2);
        quantityTextView.setText("" + number);
    }

    public void reset(View v)
    {
        n=0;
        n1=0;
        displayForA(n);
        displayForB(n1);
    }
    /**
     * This method displays the given text on the screen.
     */

}


